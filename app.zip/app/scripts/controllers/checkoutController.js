
appAppcontrollers.controller('appApp-checkoutCntrl',function checkoutController ( $scope, $rootScope, AppConstants,SelectView,SessionManager, $location,loggerService ) {
	"use strict";

	var log = loggerService('appApp-checkoutCntrl');
	log.log("Inside appApp-checkoutCntrl");


	

});

