
appAppcontrollers.controller('appApp-productsCntrl',function productsController ( $scope, $rootScope, AppConstants,SelectView,SessionManager, $location,loggerService ) {
	"use strict";

	var log = loggerService('appApp-productsCntrl');
	log.log("Inside appApp-productsCntrl");


	

});

