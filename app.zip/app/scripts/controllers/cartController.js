
appAppcontrollers.controller('appApp-cartCntrl',function cartController ( $scope, $rootScope, AppConstants,SelectView,SessionManager, $location,loggerService ) {
	"use strict";

	var log = loggerService('appApp-cartCntrl');
	log.log("Inside appApp-cartCntrl");


	

});

