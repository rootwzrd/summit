
appAppcontrollers.controller('appApp-servicesCntrl',function servicesController ( $scope, $rootScope, AppConstants,SelectView,SessionManager, $location,loggerService ) {
	"use strict";

	var log = loggerService('appApp-servicesCntrl');
	log.log("Inside appApp-servicesCntrl");


	

});

