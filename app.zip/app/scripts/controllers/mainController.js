document.addEventListener('touchmove', function(e){
	"use strict";
	e.preventDefault();
});

appAppcontrollers.controller('appApp-mainCntrl',function mainController ( $scope, $rootScope, AppConstants,SelectView,SessionManager, $location,loggerService ) {
	"use strict";

	var log = loggerService('appApp-cartCntrl');

	log.log("Inside appApp-mainCntrl");




});

